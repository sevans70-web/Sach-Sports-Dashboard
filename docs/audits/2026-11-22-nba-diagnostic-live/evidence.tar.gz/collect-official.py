import json,time,hashlib,urllib.request,urllib.error
from pathlib import Path
p=Path('/workspace/work/nba-odds-authorized-2026-11-22');report=[]
def read(name,path):
 t=time.monotonic();url='https://sach-sports-cloudflare-test.sevans70.workers.dev'+path
 try:
  try:r=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Sach-dashboard-authorized-identity-verification/1.0'}),timeout=25)
  except urllib.error.HTTPError as e:r=e
  b=r.read(3*1024*1024+1)
  if len(b)>3*1024*1024:raise ValueError('response bound exceeded')
  (p/name).write_bytes(b);d=json.loads(b);record={'path':path,'status':r.status,'seconds':round(time.monotonic()-t,3),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'rosters':len(d.get('rosters',[])),'success':d.get('success'),'gameId':d.get('gameId')};report.append(record);print(json.dumps(record),flush=True);return d
 except Exception as e:report.append({'path':path,'error':str(e),'seconds':round(time.monotonic()-t,3)});return{}
read('official-nba-slate.json','/api/game-slate?sport=nba')
ids=set()
for market in ['points','rebounds','assists','threes_made','pts_rebs_asts','pts_rebs','pts_asts']:
 for row in json.loads((p/('after-nba-'+market+'-rankings.json')).read_text()).get('rows',[]):ids.add(str(row['gameId']))
for id in sorted(ids):read('official-rosters-'+id+'.json','/api/game-slate-detail?sport=nba&gameId='+id)
(p/'official-receipts.json').write_text(json.dumps(report,indent=2))
