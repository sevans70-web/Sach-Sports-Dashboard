import json,re
from pathlib import Path
p=Path('/workspace/work/nba-odds-authorized-2026-11-22');b=json.loads((p/'cards-browser.json').read_text());markets=['points','rebounds','assists','threes_made','pts_rebs_asts','pts_rebs','pts_asts'];report={'scope':'Actual desktop/mobile cards compared against their own retained API responses, not a later viewport snapshot.','views':{},'issues':[]}
for view in ['desktop','mobile']:
 checks=b['views'][view]['nba']['checks'];assert len(checks)==7;rs=[]
 for market,c in zip(markets,checks):
  raw=json.loads((p/('cards-'+view+'-nba-'+market+'-rankings.json')).read_text())['rows'];byid={str(r['playerId']):r for r in raw};n=0;ev=0;drift=[]
  for card in c['cards']:
   r=byid.get(str(card['playerId']));text=card['text'];issue=[]
   if not r or card['market']!=market:issue.append('identity_or_category')
   else:
    f=r['researchForecast'];v=r['nbaEv'];projection=re.search(r'Sach Projection\n([\d.]+)',text);line=re.search(r'O/U ([\d.]+)',text);side=re.search(r'Sach Prediction\n(OVER|UNDER|AT LINE)',text);o=re.search(r'Over ([+-]?\d+)',text);u=re.search(r'Under ([+-]?\d+)',text)
    if r['playerName']not in text or r['matchup']not in text or not projection or float(projection[1])!=f['projection']or not line or float(line[1])!=r['sportsbookLine']:issue.append('player_opponent_projection_line')
    if not side or side[1]!=(v.get('side') if v['status']=='available'else'AT LINE'):issue.append('displayed_direction')
    quote_same=o and u and int(o[1])==r['overPrice'] and int(u[1])==r['underPrice']
    if v['status']=='available':
     expected=('+'if v['percent']>0 else'')+f"{v['percent']:.1f}%";shown=re.search(r'\nEV\n([^\n]+)',text)
     if shown and shown[1]==expected:ev+=1
     elif quote_same:issue.append('ev_display')
     else:drift.append({'playerId':r['playerId'],'rank':r['rank'],'reason':'Displayed earlier quote differs from retained later API quote','displayedEv':shown[1]if shown else None,'laterApiEV':expected})
    elif v['reason']in text and '\nEV\n—'in text:ev+=1
    else:issue.append('unavailable_reason')
   if issue:report['issues'].append({'view':view,'market':market,'playerId':card.get('playerId'),'issues':issue})
   else:n+=1
  rs.append({'market':market,'cards':len(c['cards']),'identityProjectionLineDirectionPassed':n,'exactEVOrUnavailableNoticeMatchedLatestAPI':ev,'earlierQuoteSnapshots':drift,'lowestRank':25})
 report['views'][view]=rs
report['summary']={'cards':sum(x['cards']for rs in report['views'].values()for x in rs),'identityProjectionLineDirectionPassed':sum(x['identityProjectionLineDirectionPassed']for rs in report['views'].values()for x in rs),'exactEvOrUnavailableNoticeLatestSnapshotMatches':sum(x['exactEVOrUnavailableNoticeMatchedLatestAPI']for rs in report['views'].values()for x in rs),'earlierSnapshotComparisons':sum(len(x['earlierQuoteSnapshots'])for rs in report['views'].values()for x in rs),'issues':len(report['issues'])};(p/'cards-same-response-verification.json').write_text(json.dumps(report,indent=2));print(json.dumps(report['summary']));print(json.dumps(report['issues'][:4]))
