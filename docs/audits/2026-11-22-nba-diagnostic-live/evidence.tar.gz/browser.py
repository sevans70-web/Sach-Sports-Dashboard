import os,json,time,sys
from pathlib import Path
from urllib.parse import urlparse,parse_qs
from playwright.sync_api import sync_playwright
out=Path('/workspace/work/nba-odds-authorized-2026-11-22');stage=sys.argv[1];base='https://sach-sports-cloudflare-test.sevans70.workers.dev';report={'stage':stage,'scope':'actual production Chromium, desktop/mobile, TLS enabled; auxiliary write/history endpoints suppressed','views':{},'pageErrors':[],'hydrationErrors':[],'requests':[],'suppressed':[]};markets=['Points','Rebounds','Assists','Threes','PRA','Points + Rebounds','Points + Assists']
with sync_playwright() as p:
 proxy=os.environ.get('HTTPS_PROXY') or os.environ.get('HTTP_PROXY');browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'],**({'proxy':{'server':proxy}} if proxy else {}))
 for view,size in [('desktop',{'width':1440,'height':1000}),('mobile',{'width':390,'height':844})]:
  context=browser.new_context(viewport=size,timezone_id='America/Toronto');page=context.new_page();page.on('pageerror',lambda e:report['pageErrors'].append(str(e)));page.on('console',lambda m:report['hydrationErrors'].append(m.text) if m.type=='error' and ('hydrat' in m.text.lower() or 'Minified React error' in m.text) else None)
  def guard(route):
   path=urlparse(route.request.url).path
   if path.endswith('/rankings') or path.endswith('/dashboard-summary') or path.endswith('/schedule') or path=='/api/game-slate':route.continue_();return
   report['suppressed'].append(path);route.fulfill(status=503,content_type='application/json',body=json.dumps({'success':False,'error':'Auxiliary request excluded from read-only diagnostic acceptance','rows':[],'points':[]}))
  page.route('**/api/**',guard)
  def record(r):
   path=urlparse(r.url).path
   if '/api/' in path:report['requests'].append({'path':path,'query':urlparse(r.url).query,'status':r.status})
   if path.endswith('/rankings') and r.status==200:
    try:
     sport=path.split('/')[2];market=parse_qs(urlparse(r.url).query).get('market',['points'])[0];(out/(stage+'-'+view+'-'+sport+'-'+market+'-rankings.json')).write_text(json.dumps(r.json()))
    except Exception:pass
  page.on('response',record);report['views'][view]={}
  for sport in (['nba'] if stage=='cards' else ['nba','nfl','nhl']):
   try:
    t=time.monotonic();resp=page.goto(base+'/'+sport,wait_until='domcontentloaded',timeout=60000);group=page.get_by_role('group',name=sport.upper()+' player prop markets');group.wait_for(timeout=45000);page.wait_for_timeout(2000)
    checks=[];buttons=group.get_by_role('button');labels=buttons.all_text_contents();selected=[0,1,2,3,7,8,9] if stage in ['after','cards'] and sport=='nba' else range(min(1,len(labels)))
    allowed=['Points','Rebounds','Assists','Three Pointers','PRA','Pts + Rebs','Pts + Asts']
    for i in selected:
     label=labels[i]
     buttons.nth(i).click();page.wait_for_timeout(1000)
     for _ in range(100):
      busy=page.locator('section.rankings [aria-busy]').first.get_attribute('aria-busy')
      if busy=='false':break
      page.wait_for_timeout(200)
     more=page.get_by_role('button',name='View All Rankings',exact=True)
     if more.count():more.click();page.wait_for_timeout(100)
     cards=page.locator('section.rankings article').evaluate_all('es=>es.map(e=>({playerId:e.dataset.rankingPlayer,market:e.dataset.rankingMarket,text:e.innerText}))')
     checks.append({'label':label,'ready':busy=='false','cards':cards,'count':len(cards),'notice':page.locator('section.rankings').inner_text()[-1400:]})
    report['views'][view][sport]={'http':resp.status,'seconds':round(time.monotonic()-t,3),'labels':labels,'checks':checks,'overflow':page.evaluate('document.documentElement.scrollWidth>innerWidth')};page.screenshot(path=str(out/(stage+'-'+view+'-'+sport+'.png')),full_page=True)
   except Exception as e:report['views'][view][sport]={'error':str(e)}
   (out/(stage+'-browser.json')).write_text(json.dumps(report,indent=2));print(stage,view,sport,json.dumps({k:v for k,v in report['views'][view][sport].items() if k not in ['checks','labels']}),flush=True)
  context.close()
 browser.close()
