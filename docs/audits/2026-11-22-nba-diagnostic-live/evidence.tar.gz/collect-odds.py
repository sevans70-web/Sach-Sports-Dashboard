import json,time,hashlib,urllib.request,urllib.error,datetime
from pathlib import Path
out=Path('/workspace/work/nba-odds-authorized-2026-11-22');report=[]
for market in ['points','rebounds','assists','threes_made','pts_rebs_asts','pts_rebs','pts_asts']:
 url='https://sach-sports-cloudflare-test.sevans70.workers.dev/api/market-coverage?sport=nba&mode=feed-sample&market='+market+'&limit=25';at=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
 try:
  request=urllib.request.Request(url,headers={'User-Agent':'Sach-dashboard-authorized-odds-verification/1.0'})
  try:r=urllib.request.urlopen(request,timeout=35)
  except urllib.error.HTTPError as e:r=e
  body=r.read(12*1024*1024+1);status=r.status;seconds=time.monotonic()-start
  if len(body)>12*1024*1024:raise ValueError('bounded response exceeds12MiB; do not claim complete data')
  (out/('odds-'+market+'.json')).write_bytes(body)
  try:b=json.loads(body)
  except ValueError:b={}
  report.append({'market':market,'url':url,'startedAt':at,'status':status,'seconds':round(seconds,3),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'responseMarket':b.get('market'),'diagnostics':b.get('diagnostics'),'error':b.get('error'),'reason':b.get('reason'),'cacheControl':r.headers.get('Cache-Control'),'cfRay':r.headers.get('CF-Ray')});print(json.dumps(report[-1]),flush=True)
 except Exception as e:report.append({'market':market,'startedAt':at,'seconds':round(time.monotonic()-start,3),'error':str(e)});print(json.dumps(report[-1]),flush=True)
 (out/'odds-receipts.json').write_text(json.dumps(report,indent=2))
