import json,gzip,hashlib,math,re,unicodedata,collections,datetime,sys
from pathlib import Path
p=Path('/workspace/work/nba-odds-authorized-2026-11-22');repo=Path('/workspace/Sach-Sports-Dashboard/frontend');prefix=sys.argv[1]if len(sys.argv)>1 else'after';markets=['points','rebounds','assists','threes_made','pts_rebs_asts','pts_rebs','pts_asts']
manifest=json.loads((repo/'model-runtime/manifest.json').read_text());compressed=(repo/'model-runtime/snapshot.json.gz').read_bytes();assert hashlib.sha256(compressed).hexdigest()==manifest['sha256'];snapshot=json.loads(gzip.decompress(compressed));combos=json.loads((repo/'model-runtime/nba-combination-models.json').read_text());assert combos['sourceSha256']==manifest['sha256'];models={m['group']:m for m in snapshot['models']+combos['models']}
def norm(x):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',str(x)).encode('ascii','ignore').decode().lower())
def ts(x):return datetime.datetime.fromisoformat(str(x).replace('Z','+00:00')).timestamp()
def linear(m,x):return m['coefficients'][0]+sum((v-m['means'][i])/m['scales'][i]*m['coefficients'][i+1] for i,v in enumerate(x))
def rnd(x):return math.floor(x+.5)
def price(odds):return odds/100 if odds>0 else 100/abs(odds)
def num(x):return type(x) in [int,float] and math.isfinite(x)
slate=json.loads((p/'official-nba-slate.json').read_text());games={str(g['id']):g for g in slate['games']};sourcegames={};entries={};report={'scope':'Actual November22 production responses, official current roster/game readbacks, independently reconstructed frozen model math and EV. Original source/decision times preserved; not a calibration approval or full source-population census.','snapshotSha256':manifest['sha256'],'markets':[],'failures':[],'rows':[]}
for market in markets:
 sample=json.loads((p/('odds-'+market+'.json')).read_text());index=collections.defaultdict(list);sourceKinds=collections.Counter();providerPlayers=set()
 for g in sample['games']:
  match=[v for v in games.values() if norm(v['awayTeam'])==norm(g['awayTeam']) and norm(v['homeTeam'])==norm(g['homeTeam']) and abs(ts(v['date'])-ts(g['commenceTime']))<=900];assert len(match)==1,(g['gameId'],match);sourcegames[g['gameId']]=match[0]
  for book in g['books']:
   for prop in book['props']:
    index[(g['gameId'],book['key'],prop.get('propId'))].append(prop);providerPlayers.add((g['gameId'],norm(prop.get('playerName'))));o,u=prop.get('overPrice'),prop.get('underPrice');sourceKinds['completeTwoSidedAmerican' if num(o) and num(u) and abs(o)>=100 and abs(u)>=100 else 'incompleteOrInvalidAmerican']+=1
 entries[market]=index
 board=json.loads((p/(prefix+'-nba-'+market+'-rankings.json')).read_text());rows=board.get('rows',[]);assert board['success'] and len(rows)==25
 stat={'market':market,'returnedRows':len(rows),'sourceOffers':sample['diagnostics']['returnedProps'],'sourceMatchedBeforeSampleLimit':sample['diagnostics']['matchedPropsInReturnedBooks'],'omittedOffers':sample['diagnostics']['propsOmitted'],'diagnosticTruncated':sample['diagnostics']['truncated'],'uniqueProviderPlayersInSample':len(providerPlayers),'sourcePrices':dict(sourceKinds),'identityPassed':0,'modelMathPassed':0,'probabilityPassed':0,'apiEVPassed':0,'evUnavailable':[],'sourceQuoteMatches':collections.Counter(),'evSigns':collections.Counter(),'explicitSourcePlayerIds':0,'explicitSourcePeriods':0}
 for r in rows:
  issues=[];f=r.get('researchForecast',{});pc=f.get('priceComparison') or {};ev=r.get('nbaEv') or {};game=games.get(str(r.get('gameId')));gId=str(r['gameId']);rosters=json.loads((p/('official-rosters-'+gId+'.json')).read_text());players=[(team,player)for team in rosters['rosters']for player in team['players'] if str(player['playerId'])==str(r['playerId'])];binding=pc.get('quoteEvidence') or {}
  identity=bool(game and len(players)==1 and norm(players[0][1]['playerName'])==norm(r['playerName']) and str(players[0][0]['teamId'])==str(r['teamId']) and ts(game['date'])==ts(r['gameTime']) and r['market']==market and r['quoteMarket']==market and r['quotePeriod']=='game' and r['pregameContext']['gameId']==r['gameId'] and str(r['pregameContext']['playerId'])==str(r['playerId']))
  if identity:stat['identityPassed']+=1
  else:issues.append('official_player_team_game_identity')
  expected={'sport':'nba','market':market,'gameId':gId,'playerId':str(r['playerId']),'quoteId':r['quoteId'],'sportsbookKey':r['sportsbookKey'],'line':r['sportsbookLine'],'overPrice':r['overPrice'],'underPrice':r['underPrice']}
  if any(binding.get(k)!=v for k,v in expected.items()):issues.append('exact_forecast_quote_binding')
  if not(ts(r['quoteUpdatedAt'])<=ts(f['calculatedAt'])+60 and ts(f['calculatedAt'])-ts(r['quoteUpdatedAt'])<=900 and ts(f['calculatedAt'])<ts(r['gameTime']) and ts(f['latestHistoryAt'])<ts(f['calculatedAt'])-48*3600):issues.append('source_or_forecast_freshness')
  m=models['nba|'+market];x=f['inputReceipt']['features'];work=max(0,linear(m['workload'],x));rate=linear(m['rate'],x);projection=linear(m['direct'],x) if m.get('direct') else work*rate
  if m.get('minimum') is not None:projection=max(m['minimum'],projection)
  model_ok=f['modelGroup']=='nba|'+market and f['snapshotSha256']==manifest['sha256'] and rnd(projection*10)/10==f['projection'] and rnd(work*10)/10==f['expectedWorkload']
  if model_ok:stat['modelMathPassed']+=1
  else:issues.append('original_model_projection_or_workload')
  calibration=m.get('workloadCalibration')
  if calibration:
   selected=sorted(enumerate(calibration),key=lambda t:(abs(t[1]['expectedWorkload']-work),t[0]))[:max(100,math.ceil(len(calibration)/2))];residuals=[v['residual']for _,v in selected]
  else:residuals=m['residuals']
  values=[]
  for e in residuals:
   v=projection+e
   if m.get('minimum') is not None:v=max(m['minimum'],v)
   values.append(rnd(v*2)/2 if m.get('halfPoint') else rnd(v) if m['integer'] else v)
  line=r['sportsbookLine'];over=sum(v>line for v in values)/len(values);under=sum(v<line for v in values)/len(values);push=sum(v==line for v in values)/len(values)
  if all(abs(a-b)<1e-10 for a,b in [(over,pc['overProbability']),(under,pc['underProbability']),(push,pc['pushProbability'])]) and abs(over+under+push-1)<1e-10:stat['probabilityPassed']+=1
  else:issues.append('reconstructed_probabilities')
  over_ev=over*price(r['overPrice'])-under;under_ev=under*price(r['underPrice'])-over
  if abs(pc['overExpectedReturn']-over_ev)>1e-10 or abs(pc['underExpectedReturn']-under_ev)>1e-10:issues.append('probability_price_comparison_ev')
  if ev.get('status')=='available':
   side=ev['side'];win=over if side=='OVER'else under;expected_ev=(over_ev if side=='OVER'else under_ev)*100
   if abs(ev['percent']-expected_ev)<1e-9 and abs(ev['winProbability']-win)<1e-10:stat['apiEVPassed']+=1
   else:issues.append('reported_api_ev')
   selection=f.get('modelSelection');expectedSide=selection.get('side') if selection else 'OVER' if f['projection']>line else 'UNDER' if f['projection']<line else None
   if side!=expectedSide:issues.append('display_direction')
   stat['evSigns']['positive'if ev['percent']>0 else 'negative'if ev['percent']<0 else 'exactZero']+=1
  else:stat['evUnavailable'].append({'rank':r['rank'],'playerId':r['playerId'],'playerName':r['playerName'],'code':ev.get('code'),'reason':ev.get('reason'),'projection':f['projection'],'line':line})
  props=index.get((r['providerEventId'],r['sportsbookKey'],r['quoteId']),[]);category='outside_bounded_diagnostic'
  if props:
   matches=[q for q in props if q.get('line')==line and norm(q.get('playerName'))==norm(r['playerName'])]
   if matches:
    q=matches[0];category='same_id_player_game_line_prices'if q.get('overPrice')==r['overPrice'] and q.get('underPrice')==r['underPrice'] else 'same_id_player_game_line_later_price_snapshot'
   else:category='same_id_different_line_or_name_snapshot'
  stat['sourceQuoteMatches'][category]+=1
  rr={'market':market,'rank':r['rank'],'playerId':r['playerId'],'playerName':r['playerName'],'gameId':gId,'providerEventId':r['providerEventId'],'quoteId':r['quoteId'],'book':r['sportsbookKey'],'line':line,'overPrice':r['overPrice'],'underPrice':r['underPrice'],'projection':f['projection'],'overProbability':over,'underProbability':under,'pushProbability':push,'side':ev.get('side'),'evPercent':ev.get('percent'),'evStatus':ev.get('status'),'sourceSampleMatch':category,'officialIdentityVerified':identity,'issues':issues};report['rows'].append(rr)
  if issues:report['failures'].append(rr)
 stat['sourceQuoteMatches']=dict(stat['sourceQuoteMatches']);stat['evSigns']=dict(stat['evSigns']);report['markets'].append(stat)
report['sourceFixtureJoins']=[{'providerGameId':key,'officialGameId':g['id'],'officialStart':g['date'],'teams':[g['awayTeam'],g['homeTeam']]}for key,g in sourcegames.items()];report['summary']={'currentMarkets':7,'rowsAudited':len(report['rows']),'officialPlayerGameIdentityPassed':sum(m['identityPassed']for m in report['markets']),'independentModelMathPassed':sum(m['modelMathPassed']for m in report['markets']),'independentProbabilityPassed':sum(m['probabilityPassed']for m in report['markets']),'independentApiEVPassed':sum(m['apiEVPassed']for m in report['markets']),'unavailableEVs':sum(len(m['evUnavailable'])for m in report['markets']),'failureRows':len(report['failures']),'fullEligiblePopulationVerified':False,'sourceCompletenessLimitation':'Per-book samples truncate1010of5518offers; no explicit provider player IDs/period fields; official joins provide independent row identity, not missing raw IDs.'};(p/('live-independent-verification.json'if prefix=='after'else prefix+'-independent-verification.json')).write_text(json.dumps(report,indent=2));print(json.dumps({'summary':report['summary'],'markets':report['markets'],'failureExamples':report['failures'][:2]},indent=2))
