export default {
  "clientEntryUrl": "/_next/static/chunks/DLyfFIl_.js",
  "clientEntryDeps": {
    "js": [
      "/_next/static/chunks/DLyfFIl_.js",
      "/_next/static/chunks/CcyWYbDU.js",
      "/_next/static/chunks/B0PXqnjO.js",
      "/_next/static/chunks/INw_BLsD.js"
    ],
    "css": []
  },
  "clientReferenceDeps": {
    "3325fec8e08d": {
      "js": [
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "bce72efe64cd": {
      "js": [
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "403fc9b8da25": {
      "js": [
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "cff13da9274d": {
      "js": [
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "350f15db9676": {
      "js": [
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "97e05a92ac2d": {
      "js": [
        "/_next/static/chunks/BKy2yycr.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "c2747888630f": {
      "js": [
        "/_next/static/chunks/fSbtfBoG.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/D6O2yFoV.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "f702b52fecd0": {
      "js": [
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "2507f41b0125": {
      "js": [
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "6c2c58f4d893": {
      "js": [
        "/_next/static/chunks/CzL0Qu7k.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "fe9ce72087a3": {
      "js": [
        "/_next/static/chunks/jygVbZ1P.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/D6O2yFoV.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "33942307afe6": {
      "js": [
        "/_next/static/chunks/DNYh4KcY.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/Z4foo45g.js",
        "/_next/static/chunks/D6O2yFoV.js",
        "/_next/static/chunks/44e9MdSJ.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": [
        "/_next/static/css/wQTlv5GA.css"
      ]
    },
    "6ea1e3c9d977": {
      "js": [
        "/_next/static/chunks/V7lh5WIF.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "96188f59ccf9": {
      "js": [
        "/_next/static/chunks/DTW5G0vY.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/Z4foo45g.js",
        "/_next/static/chunks/D6O2yFoV.js",
        "/_next/static/chunks/44e9MdSJ.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/8dm2iH9f.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "db2f0ab6401a": {
      "js": [
        "/_next/static/chunks/CxgYHy29.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/yVQh1iy9.js",
        "/_next/static/chunks/CTho-w5l.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": [
        "/_next/static/css/CRvJVD36.css"
      ]
    },
    "220b468028f4": {
      "js": [
        "/_next/static/chunks/-mmSifr_.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/yVQh1iy9.js",
        "/_next/static/chunks/CTho-w5l.js",
        "/_next/static/chunks/8dm2iH9f.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": [
        "/_next/static/css/CRvJVD36.css"
      ]
    },
    "d1ee8c8dedcc": {
      "js": [
        "/_next/static/chunks/DvNZ8Jcm.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BE3tz1HM.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/D6O2yFoV.js",
        "/_next/static/chunks/9GUNbVcE.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": [
        "/_next/static/css/BLuhaFKG.css"
      ]
    },
    "6b52ea9bc843": {
      "js": [
        "/_next/static/chunks/CossspUS.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/CGCpAov2.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/BE3tz1HM.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": [
        "/_next/static/css/OsCvmTbS.css"
      ]
    },
    "91ead71c14ab": {
      "js": [
        "/_next/static/chunks/DTW5G0vY.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/Z4foo45g.js",
        "/_next/static/chunks/D6O2yFoV.js",
        "/_next/static/chunks/44e9MdSJ.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/8dm2iH9f.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": []
    },
    "2bd1fae1b36a": {
      "js": [
        "/_next/static/chunks/Dxi4CHut.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/D6O2yFoV.js",
        "/_next/static/chunks/9GUNbVcE.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/BE3tz1HM.js",
        "/_next/static/chunks/CGCpAov2.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/D-1KEvrD.js",
        "/_next/static/chunks/CTho-w5l.js",
        "/_next/static/chunks/44e9MdSJ.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": [
        "/_next/static/css/ClOj6lLi.css",
        "/_next/static/css/OsCvmTbS.css",
        "/_next/static/css/-BXG3uFF.css"
      ]
    },
    "26120ec687fa": {
      "js": [
        "/_next/static/chunks/V2eSPfLp.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/INw_BLsD.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/D-1KEvrD.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/CTho-w5l.js",
        "/_next/static/chunks/BE3tz1HM.js",
        "/_next/static/chunks/9GUNbVcE.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/DLyfFIl_.js"
      ],
      "css": [
        "/_next/static/css/VJLkRnPZ.css",
        "/_next/static/css/-BXG3uFF.css"
      ]
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/Cal6PRCu.css"
      ]
    }
  }
}