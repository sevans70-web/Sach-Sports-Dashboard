import{a as e}from"./navigation-errors-DAOpTDSc.js";import"./navigation.react-server-54muMimQ.js";function t(){e(`/cbb`)}export{t as default};
//# sourceMappingURL=page-C9v1IhUK.js.map