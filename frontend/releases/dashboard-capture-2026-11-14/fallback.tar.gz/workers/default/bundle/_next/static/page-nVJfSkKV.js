import{a as e}from"./navigation-errors-DAOpTDSc.js";import"./navigation.react-server-54muMimQ.js";function t(){e(`/`)}export{t as default};
//# sourceMappingURL=page-nVJfSkKV.js.map