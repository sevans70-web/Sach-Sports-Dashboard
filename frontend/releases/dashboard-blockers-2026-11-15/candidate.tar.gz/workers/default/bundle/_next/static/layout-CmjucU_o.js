function e({children:e}){return e}export{e as default};
//# sourceMappingURL=layout-CmjucU_o.js.map