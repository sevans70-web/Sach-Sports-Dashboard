import{a as e}from"./navigation-errors-DAOpTDSc.js";import"./navigation.react-server-CvW5PmtI.js";function t(){e(`/cbb`)}export{t as default};
//# sourceMappingURL=page-KthdW2vl.js.map