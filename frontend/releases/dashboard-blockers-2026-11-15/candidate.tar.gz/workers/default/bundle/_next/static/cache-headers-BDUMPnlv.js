import{p as e,s as t}from"./headers-DTMGMjpx.js";function n(e){return e===`STATIC`?`HIT`:e}function r(r,i){r.set(e,i),r.set(t,n(i))}export{r as t};
//# sourceMappingURL=cache-headers-BDUMPnlv.js.map