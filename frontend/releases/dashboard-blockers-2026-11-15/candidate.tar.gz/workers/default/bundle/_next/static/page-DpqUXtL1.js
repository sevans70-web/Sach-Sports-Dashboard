import{a as e}from"./navigation-errors-DAOpTDSc.js";import"./navigation.react-server-CvW5PmtI.js";function t(){e(`/`)}export{t as default};
//# sourceMappingURL=page-DpqUXtL1.js.map