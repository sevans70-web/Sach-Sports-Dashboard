function e({children:e}){return e}export{e as default};
//# sourceMappingURL=layout-C4N5zhhj.js.map