function e(){return globalThis.__sachDashboardJobContext?.()}export{e as t};
//# sourceMappingURL=dashboard-job-context-CGbiGq9-.js.map