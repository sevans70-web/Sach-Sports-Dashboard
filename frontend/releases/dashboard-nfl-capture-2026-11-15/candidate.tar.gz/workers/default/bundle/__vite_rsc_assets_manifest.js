export default {
  "clientEntryUrl": "/_next/static/chunks/BjeUlM53.js",
  "clientEntryDeps": {
    "js": [
      "/_next/static/chunks/BjeUlM53.js",
      "/_next/static/chunks/CcyWYbDU.js",
      "/_next/static/chunks/B0PXqnjO.js",
      "/_next/static/chunks/BD8bqAsM.js"
    ],
    "css": []
  },
  "clientReferenceDeps": {
    "6c2c58f4d893": {
      "js": [
        "/_next/static/chunks/YEe-DcWH.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "fe9ce72087a3": {
      "js": [
        "/_next/static/chunks/Bv2XI2vL.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/CaQzgKBd.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "33942307afe6": {
      "js": [
        "/_next/static/chunks/DRYi8h65.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/Ls-PFZTQ.js",
        "/_next/static/chunks/CaQzgKBd.js",
        "/_next/static/chunks/44e9MdSJ.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": [
        "/_next/static/css/wQTlv5GA.css"
      ]
    },
    "6ea1e3c9d977": {
      "js": [
        "/_next/static/chunks/D5lbz9oR.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "96188f59ccf9": {
      "js": [
        "/_next/static/chunks/4TBrp7eg.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/Ls-PFZTQ.js",
        "/_next/static/chunks/CaQzgKBd.js",
        "/_next/static/chunks/44e9MdSJ.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/8dm2iH9f.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "db2f0ab6401a": {
      "js": [
        "/_next/static/chunks/C-AFkwzP.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/yVQh1iy9.js",
        "/_next/static/chunks/CTho-w5l.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": [
        "/_next/static/css/CRvJVD36.css"
      ]
    },
    "220b468028f4": {
      "js": [
        "/_next/static/chunks/BMSW_Jth.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/yVQh1iy9.js",
        "/_next/static/chunks/CTho-w5l.js",
        "/_next/static/chunks/8dm2iH9f.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": [
        "/_next/static/css/CRvJVD36.css"
      ]
    },
    "d1ee8c8dedcc": {
      "js": [
        "/_next/static/chunks/CTl6EiDf.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BE3tz1HM.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/CaQzgKBd.js",
        "/_next/static/chunks/9GUNbVcE.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": [
        "/_next/static/css/BLuhaFKG.css"
      ]
    },
    "6b52ea9bc843": {
      "js": [
        "/_next/static/chunks/BEDXpiQI.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/CGCpAov2.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/BE3tz1HM.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": [
        "/_next/static/css/OsCvmTbS.css"
      ]
    },
    "91ead71c14ab": {
      "js": [
        "/_next/static/chunks/4TBrp7eg.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/Ls-PFZTQ.js",
        "/_next/static/chunks/CaQzgKBd.js",
        "/_next/static/chunks/44e9MdSJ.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/8dm2iH9f.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "2bd1fae1b36a": {
      "js": [
        "/_next/static/chunks/Bx6udM7N.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/CaQzgKBd.js",
        "/_next/static/chunks/9GUNbVcE.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/BRrtHjxy.js",
        "/_next/static/chunks/BE3tz1HM.js",
        "/_next/static/chunks/CGCpAov2.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/D-1KEvrD.js",
        "/_next/static/chunks/CTho-w5l.js",
        "/_next/static/chunks/44e9MdSJ.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": [
        "/_next/static/css/ClOj6lLi.css",
        "/_next/static/css/OsCvmTbS.css",
        "/_next/static/css/-BXG3uFF.css"
      ]
    },
    "26120ec687fa": {
      "js": [
        "/_next/static/chunks/BIPTDxsN.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/D-1KEvrD.js",
        "/_next/static/chunks/DK6CqEyk.js",
        "/_next/static/chunks/fu53Dimw.js",
        "/_next/static/chunks/CTho-w5l.js",
        "/_next/static/chunks/BE3tz1HM.js",
        "/_next/static/chunks/9GUNbVcE.js",
        "/_next/static/chunks/b-5sHkJL.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": [
        "/_next/static/css/VJLkRnPZ.css",
        "/_next/static/css/-BXG3uFF.css"
      ]
    },
    "9276801271d6": {
      "js": [
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "3b65333b902f": {
      "js": [
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "0b874ad30386": {
      "js": [
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "593f344dc510": {
      "js": [
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "bad85346fc72": {
      "js": [
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "15c18cfaeeff": {
      "js": [
        "/_next/static/chunks/gUDl0RJF.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "c2747888630f": {
      "js": [
        "/_next/static/chunks/BuFggHtf.js",
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/CaQzgKBd.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "8c0f216c4604": {
      "js": [
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    },
    "89c3cac48cb5": {
      "js": [
        "/_next/static/chunks/BD8bqAsM.js",
        "/_next/static/chunks/CcyWYbDU.js",
        "/_next/static/chunks/B0PXqnjO.js",
        "/_next/static/chunks/BjeUlM53.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/Cal6PRCu.css"
      ]
    }
  }
}