import { env } from "cloudflare:workers";
import { createHash } from "node:crypto";
// lib/worker-runtime-secret.ts
/**
* Cloudflare staging-only runtime secret reader.
* Reads Workers bindings directly rather than relying on Node process.env
* population, which can differ between runtimes/framework adapters.
* Never log, return to an API response, or cache the secret values.
*/
function workerRuntimeSecret(name) {
	const binding = workerRuntimeBinding(name);
	if (typeof binding === "string" && binding.trim()) return binding.trim();
	const fallback = process.env[name];
	return typeof fallback === "string" ? fallback.trim() : "";
}
function workerRuntimeBinding(name) {
	return env[name];
}
// lib/provider-fetch.ts
const PUBLIC_PROVIDER_USER_AGENT = "Mozilla/5.0 (compatible; SachSports/1.0)";
const shared = globalThis;
const state = shared.__sachProviderTransportV2 || (shared.__sachProviderTransportV2 = {
	cache: /* @__PURE__ */ new Map(),
	pending: /* @__PURE__ */ new Map(),
	bytes: 0
});
const { cache: cache$2, pending: pending$2 } = state;
const MAX_CACHE_BYTES = 33554432;
const MAX_ENTRY_BYTES = 8388608;
function removeCached(key) {
	const old = cache$2.get(key);
	if (old) {
		state.bytes -= old.bytes;
		cache$2.delete(key);
	}
}
function responseFrom(value) {
	return new Response([
		204,
		205,
		304
	].includes(value.status) ? null : value.body, {
		status: value.status,
		headers: value.headers
	});
}
async function providerFetch(input, init) {
	const job = globalThis.__sachDashboardJobContext?.();
	job?.assertActive();
	const url = String(input), pendingKey = (job ? "dashboard-job:" + job.id + "|" : "") + url;
	const host = new URL(url).hostname;
	const nhlStarted = state.nhlStarted ??= /* @__PURE__ */ new Map();
	if (![
		"site.api.espn.com",
		"site.web.api.espn.com",
		"api-web.nhle.com",
		"api.nhle.com"
	].includes(host) || init?.method && init.method !== "GET") return globalThis.fetch(input, {
		...init,
		signal: init?.signal ?? AbortSignal.timeout(1e4)
	});
	for (const [key, value] of cache$2) if (value.expires <= Date.now()) removeCached(key);
	const hit = cache$2.get(url);
	if (hit && hit.expires > Date.now()) return responseFrom(hit);
	const hockey = host === "api-web.nhle.com" || host === "api.nhle.com";
	if (hockey && pending$2.has(pendingKey) && Date.now() - (nhlStarted.get(pendingKey) || 0) >= 8500) {
		pending$2.delete(pendingKey);
		nhlStarted.delete(pendingKey);
	}
	const running = pending$2.get(pendingKey);
	if (running) {
		if (!hockey) return responseFrom(await running);
		let timer;
		try {
			return responseFrom(await Promise.race([running, new Promise((_, reject) => {
				timer = setTimeout(() => reject(Error("NHL provider read timed out")), 8e3);
			})]));
		} finally {
			if (timer) clearTimeout(timer);
			if (pending$2.get(pendingKey) === running) {
				pending$2.delete(pendingKey);
				nhlStarted.delete(pendingKey);
			}
		}
	}
	let work;
	work = (async () => {
		const headers = new Headers(init?.headers);
		headers.set("Accept", "application/json");
		headers.set("User-Agent", PUBLIC_PROVIDER_USER_AGENT);
		const options = {
			...init,
			headers,
			cache: "no-store",
			signal: init?.signal ?? AbortSignal.timeout(8e3)
		};
		let response = await globalThis.fetch(input, options);
		if ([
			502,
			503,
			504
		].includes(response.status) && host.endsWith(".espn.com")) {
			const alternate = new URL(url);
			alternate.hostname = host === "site.api.espn.com" ? "site.web.api.espn.com" : "site.api.espn.com";
			const retry = await globalThis.fetch(alternate, {
				...options,
				signal: init?.signal ?? AbortSignal.timeout(8e3)
			});
			if (retry.ok) {
				await response.body?.cancel().catch(() => {});
				response = retry;
			} else await retry.body?.cancel().catch(() => {});
		}
		const body = await response.text();
		const value = {
			body,
			status: response.status,
			headers: response.headers
		};
		if (response.ok && (!hockey || pending$2.get(pendingKey) === work)) {
			const ttl = /statistics|\/stats[/?]|\/roster|byathlete/.test(url) || host === "api-web.nhle.com" && /\/player\/\d+\/game-log\//.test(url) ? 9e5 : 3e4;
			const bytes = body.length * 2;
			if (bytes <= MAX_ENTRY_BYTES) {
				removeCached(url);
				while (cache$2.size && (cache$2.size >= 1024 || state.bytes + bytes > MAX_CACHE_BYTES)) removeCached(cache$2.keys().next().value);
				cache$2.set(url, {
					...value,
					expires: Date.now() + ttl,
					bytes
				});
				state.bytes += bytes;
			}
		} else console.warn("[provider unavailable]", host, new URL(url).pathname, response.status, response.headers.get("content-type"));
		return value;
	})();
	pending$2.set(pendingKey, work);
	if (hockey) nhlStarted.set(pendingKey, Date.now());
	try {
		return responseFrom(await work);
	} finally {
		if (pending$2.get(pendingKey) === work) {
			pending$2.delete(pendingKey);
			nhlStarted.delete(pendingKey);
		}
	}
}
// lib/dashboard-job-context.ts
function dashboardJobContext() {
	return globalThis.__sachDashboardJobContext?.();
}
// lib/bounded-value-cache.ts
/** Byte-accounted, disposable LRU values; no history or original evidence is evicted. */
function boundedValueCache(maxBytes, maxEntries) {
	const rows = /* @__PURE__ */ new Map();
	let bytes = 0;
	const remove = (key) => {
		const hit = rows.get(key);
		if (hit) {
			bytes -= hit.bytes;
			rows.delete(key);
		}
	};
	return {
		get(key, now = Date.now()) {
			const hit = rows.get(key);
			if (!hit) return;
			if (hit.expires <= now) {
				remove(key);
				return;
			}
			rows.delete(key);
			rows.set(key, hit);
			return hit.value;
		},
		set(key, value, ttl, now = Date.now()) {
			const size = JSON.stringify(value).length * 2;
			if (size > maxBytes) return false;
			remove(key);
			for (const [k, v] of rows) if (v.expires <= now) remove(k);
			while (rows.size && (rows.size >= maxEntries || bytes + size > maxBytes)) remove(rows.keys().next().value);
			rows.set(key, {
				value,
				expires: now + ttl,
				bytes: size
			});
			bytes += size;
			return true;
		},
		status: () => ({
			entries: rows.size,
			bytes,
			maxBytes
		}),
		clear() {
			rows.clear();
			bytes = 0;
		}
	};
}
// lib/dashboard-book-feed.ts
var BookFeedUnavailable = class extends Error {
	constructor(diagnostic) {
		super(diagnostic.code);
		this.diagnostic = diagnostic;
	}
};
const cache$1 = boundedValueCache(4194304, 8);
const pending$1 = /* @__PURE__ */ new Map();
function retryAt(value, status, now) {
	const minimum = [401, 403].includes(status) ? 18e5 : status === 429 ? 6e4 : 3e4, n = value == null ? NaN : Number(value), date = Date.parse(value || "");
	return Math.max(now + minimum, Number.isFinite(n) ? now + Math.max(n, 0) * 1e3 : Number.isFinite(date) ? date : 0);
}
const fields = (value, keys) => Object.fromEntries(keys.filter((k) => value?.[k] !== void 0).map((k) => [k, value[k]]));
/** Persist quote input only, never account metadata, headers or credentials. */
function bookQuoteSnapshot(payload) {
	if (!Array.isArray(payload?.data)) throw Error("provider_invalid_schema");
	return { data: payload.data.map((g) => ({
		...fields(g, [
			"gameId",
			"eventId",
			"id",
			"awayTeam",
			"away_team",
			"homeTeam",
			"home_team",
			"commenceTime",
			"commence_time",
			"startTime",
			"date"
		]),
		books: (Array.isArray(g.books) ? g.books : []).map((b) => ({
			...fields(b, [
				"key",
				"title",
				"name",
				"lastUpdate"
			]),
			props: (Array.isArray(b.props) ? b.props : []).map((p) => fields(p, [
				"playerName",
				"player_name",
				"team",
				"teamName",
				"category",
				"market",
				"type",
				"sourceCategory",
				"sourcePeriod",
				"periodID",
				"periodId",
				"period",
				"periodName",
				"lastUpdate",
				"suspended",
				"isSuspended",
				"active",
				"marketStructure",
				"lineType",
				"kind",
				"isAlternate",
				"isMainLine",
				"propId",
				"overPrice",
				"over_price",
				"underPrice",
				"under_price",
				"line",
				"point",
				"total",
				"event_link"
			]))
		}))
	})) };
}
function bookFeedDiagnostic(error, sport) {
	if (error instanceof BookFeedUnavailable) return error.diagnostic;
	const code = error instanceof Error && /timeout|abort/i.test(error.message) ? "request_timeout" : error instanceof Error && /provider_invalid_schema/.test(error.message) ? "provider_invalid_schema" : "provider_request_failed";
	return {
		provider: "owls",
		sport,
		endpoint: `/api/v1/${sport}/props`,
		code,
		status: null,
		retryAt: null,
		authorizationPresent: true
	};
}
async function getDashboardBookFeed(sport) {
	const job = dashboardJobContext();
	job?.assertActive();
	const key = "dashboard-book:owls:" + sport + ":v1", now = Date.now();
	const saved = job?.readInput?.(key) || (!job ? cache$1.get(key) : void 0);
	if (saved && saved.expires > now) {
		if (saved.diagnostic) throw new BookFeedUnavailable(saved.diagnostic);
		return saved.payload;
	}
	const owner = (job?.id || "foreground") + "|" + sport, existing = pending$1.get(owner);
	if (existing) return existing;
	const work = (async () => {
		const credential = workerRuntimeSecret("OWLS_INSIGHT_API_KEY");
		const fail = (code, status, expires, authorizationPresent = Boolean(credential)) => {
			const diagnostic = {
				provider: "owls",
				sport,
				endpoint: `/api/v1/${sport}/props`,
				code,
				status,
				retryAt: new Date(expires).toISOString(),
				authorizationPresent
			};
			const value = {
				diagnostic,
				expires
			};
			if (job) job.checkpointInput?.(key, value, false);
			else cache$1.set(key, value, expires - Date.now());
			throw new BookFeedUnavailable(diagnostic);
		};
		if (!credential) return fail("worker_secret_missing", null, now + 18e5, false);
		try {
			const response = await providerFetch("https://api.owlsinsight.com/api/v1/" + sport + "/props", {
				headers: {
					Authorization: "Bearer " + credential,
					"x-api-key": credential,
					Accept: "application/json"
				},
				cache: "no-store"
			});
			if (!response.ok) {
				const expires = retryAt(response.headers.get("Retry-After"), response.status, Date.now());
				await response.body?.cancel();
				return fail("provider_http_" + response.status, response.status, expires);
			}
			const payload = bookQuoteSnapshot(await response.json()), value = {
				payload,
				expires: Date.now() + 6e4
			};
			if (job) job.checkpointInput?.(key, value, true);
			else cache$1.set(key, value, 6e4);
			return payload;
		} catch (error) {
			if (error instanceof BookFeedUnavailable || error?.deferred) throw error;
			const d = bookFeedDiagnostic(error, sport);
			return fail(d.code, d.status, Date.now() + 3e4);
		}
	})();
	pending$1.set(owner, work);
	try {
		return await work;
	} finally {
		if (pending$1.get(owner) === work) pending$1.delete(owner);
	}
}
// lib/owls-provider.ts
/** Safe failure category; never return provider credentials or response bodies. */
function owlsFailureCategory(error) {
	const diagnosticCode = error?.diagnostic?.code;
	if (typeof diagnosticCode === "string" && /^(provider_http_\d{3}|worker_secret_missing|provider_invalid_schema|request_timeout|provider_request_failed)$/.test(diagnosticCode)) return diagnosticCode;
	const message = error instanceof Error ? error.message : String(error);
	if (/key is missing|not configured|missing from Railway/i.test(message)) return "worker_secret_missing";
	const status = /^Owls Insight returned (\d{3})$/.exec(message);
	if (status) return "provider_http_" + status[1];
	if (/too many subrequests/i.test(message)) return "worker_subrequest_limit";
	if (/memory limit|cpu time/i.test(message)) return "worker_resource_limit";
	if (error instanceof SyntaxError) return "provider_invalid_json";
	if (/timeout|abort/i.test(message)) return "request_timeout";
	return "provider_request_failed";
}
const cache = /* @__PURE__ */ new Map();
const pending = /* @__PURE__ */ new Map();
/** One short-lived feed snapshot per sport, shared across markets and leagues. */
async function getOwlsPayload(sport) {
	if (sport === "nfl" || sport === "nhl") return getDashboardBookFeed(sport);
	const hit = cache.get(sport);
	if (hit && hit.expires > Date.now()) {
		if (hit.error) throw new Error(hit.error);
		return hit.payload;
	}
	const running = pending.get(sport);
	if (running) return running;
	const work = (async () => {
		const key = workerRuntimeSecret("OWLS_INSIGHT_API_KEY");
		if (!key) throw new Error("OWLS_INSIGHT_API_KEY is not configured in this runtime.");
		const response = await providerFetch(`https://api.owlsinsight.com/api/v1/${sport === "cbb" ? "ncaab" : sport}/props`, {
			headers: {
				Authorization: `Bearer ${key}`,
				"x-api-key": key,
				Accept: "application/json"
			},
			cache: "no-store"
		});
		if (!response.ok) {
			const error = `Owls Insight returned ${response.status}`;
			const retry = Number(response.headers.get("retry-after"));
			const delay = response.status === 429 && Number.isFinite(retry) && retry > 0 ? Math.min(retry * 1e3, 36e5) : 3e4;
			cache.set(sport, {
				expires: Date.now() + delay,
				error
			});
			throw new Error(error);
		}
		const payload = await response.json();
		cache.set(sport, {
			expires: Date.now() + 6e4,
			payload
		});
		return payload;
	})();
	pending.set(sport, work);
	try {
		return await work;
	} finally {
		pending.delete(sport);
	}
}
// lib/basketball-markets.ts
const norm = (v) => String(v ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");
const aliases = {
	points: ["points", "playerpoints"],
	rebounds: ["rebounds", "playerrebounds"],
	assists: ["assists", "playerassists"],
	threes_made: [
		"threesmade",
		"threepointersmade",
		"threepointfieldgoalsmade",
		"3pointersmade"
	],
	pts_rebs_asts: [
		"ptsrebsasts",
		"pointsreboundsassists",
		"pra"
	],
	pts_rebs: ["ptsrebs", "pointsrebounds"],
	pts_asts: ["ptsasts", "pointsassists"],
	rebs_asts: ["rebsasts", "reboundsassists"],
	steals: ["steals"],
	blocks: ["blocks"],
	first_basket: [
		"firstbasket",
		"firstscorer",
		"firstpointscorer",
		"playerfirstbasket",
		"playerfirstbasketballscorer"
	]
};
/** Period is mandatory for quarter props; never reuse full-game lines. */
function basketballMarketMatches(prop, market) {
	const quarter = market.startsWith("q1_"), base = quarter ? market.slice(3) : market;
	const category = norm(prop.category ?? prop.market ?? prop.statID ?? prop.type);
	const period = norm(prop.periodID ?? prop.periodId ?? prop.period ?? prop.periodName);
	const q1 = [
		"1q",
		"q1",
		"1stquarter",
		"firstquarter",
		"1"
	].includes(period);
	if (period && !(quarter ? q1 : [
		"game",
		"fullgame",
		"0"
	].includes(period))) return false;
	const names = aliases[base] || [];
	if (quarter) return names.some((n) => [
		"q1" + n,
		n + "1q",
		n + "q1",
		"1stquarter" + n,
		n + "firstquarter"
	].includes(category)) || q1 && names.includes(category);
	return names.includes(category);
}
// lib/nba-feed-sample.ts
const markets = /* @__PURE__ */ new Set([
	"points",
	"rebounds",
	"assists",
	"threes_made",
	"pts_rebs_asts",
	"pts_rebs",
	"pts_asts"
]);
const allowed = (row, keys) => Object.fromEntries(keys.filter((k) => [
	"string",
	"number",
	"boolean"
].includes(typeof row?.[k]) || row != null && Object.hasOwn(row, k) && row[k] === null).map((k) => [k, row[k]]));
const present = (v) => ["string", "number"].includes(typeof v) && String(v).trim() !== "";
const numeric = (v) => present(v) && Number.isFinite(Number(v)) ? Number(v) : null;
/** Read-only public source evidence. No generated IDs, inferred periods, copied
* forecasts or reconstructed prices. Counts describe this bounded sample only. */
function nbaFeedSample(payload, market = "points", limit = 2, now = Date.now()) {
	if (!validNbaFeedSample(market, limit)) throw Error("invalid_nba_feed_sample");
	if (!Array.isArray(payload?.data)) throw Object.assign(Error("invalid_nba_feed_payload"), { diagnostic: { code: "provider_invalid_schema" } });
	const sourceGames = payload.data, gaps = {};
	let matchedProps = 0, returnedProps = 0, booksOmitted = 0, propsOmitted = 0;
	const gap = (key) => {
		gaps[key] = (gaps[key] || 0) + 1;
	};
	const games = sourceGames.slice(0, 30).map((g) => {
		const sourceBooks = Array.isArray(g.books) ? g.books : [];
		booksOmitted += Math.max(0, sourceBooks.length - 12);
		return {
			...allowed(g, [
				"id",
				"gameId",
				"eventId",
				"homeTeam",
				"awayTeam",
				"home_team",
				"away_team",
				"commenceTime",
				"commence_time",
				"startTime",
				"date"
			]),
			books: sourceBooks.slice(0, 12).map((b) => {
				const matches = (Array.isArray(b.props) ? b.props : []).filter((p) => basketballMarketMatches(p, market));
				matchedProps += matches.length;
				propsOmitted += Math.max(0, matches.length - limit);
				return {
					...allowed(b, [
						"key",
						"name",
						"lastUpdate"
					]),
					props: matches.slice(0, limit).map((p) => {
						returnedProps++;
						if (!present(p.propId)) gap("provider_prop_id_missing");
						if (![
							p.playerId,
							p.playerID,
							p.athleteId
						].some(present)) gap("provider_player_id_missing");
						if (![
							g.id,
							g.gameId,
							g.eventId
						].some(present)) gap("provider_game_id_missing");
						const start = Date.parse(g.commenceTime || g.commence_time || g.startTime || g.date || "");
						if (!Number.isFinite(start)) gap("fixture_time_missing_or_invalid");
						else if (start <= now) gap("started_fixture");
						const away = String(g.awayTeam || g.away_team || "").trim(), home = String(g.homeTeam || g.home_team || "").trim();
						if (!away || !home || away === home) gap("fixture_teams_missing_or_ambiguous");
						if (![
							p.periodID,
							p.periodId,
							p.period,
							p.periodName
						].some(present)) gap("explicit_period_missing");
						if (![p.playerName, p.player].some(present)) gap("player_name_missing");
						if (!present(b.key)) gap("sportsbook_key_missing");
						for (const key of ["gameId", "eventId"]) if (present(p[key]) && present(g[key]) && String(p[key]) !== String(g[key])) gap("provider_" + key + "_mismatch");
						const line = numeric(p.line ?? p.point ?? p.total);
						if (line == null || line < 0 || !Number.isInteger(line * 2)) gap("invalid_or_missing_line");
						if ([p.overPrice, p.underPrice].some((v) => numeric(v) == null || Math.abs(Number(v)) < 100)) gap("incomplete_two_sided_prices");
						const stamp = Date.parse(p.lastUpdate || b.lastUpdate || "");
						if (!Number.isFinite(stamp)) gap("quote_timestamp_missing");
						else if (stamp > now + 6e4) gap("future_quote_timestamp");
						else if (now - stamp > 9e5) gap("stale_quote_timestamp");
						if (p.suspended === true || p.isSuspended === true || p.active === false) gap("inactive_or_suspended");
						if (p.isAlternate === true || p.isMain === false || p.isMainLine === false) gap("not_main_market");
						return allowed(p, [
							"propId",
							"quoteId",
							"playerId",
							"playerID",
							"athleteId",
							"gameId",
							"eventId",
							"market",
							"statID",
							"type",
							"periodID",
							"periodId",
							"period",
							"periodName",
							"team",
							"teamName",
							"active",
							"isSuspended",
							"isMain",
							"playerName",
							"player",
							"category",
							"line",
							"point",
							"total",
							"overPrice",
							"underPrice",
							"lastUpdate",
							"isMainLine",
							"isAlternate",
							"marketStructure",
							"lineType",
							"suspended"
						]);
					})
				};
			})
		};
	});
	return {
		sport: "nba",
		market,
		limit,
		scope: "Bounded source sample, not a full player inventory or a prediction. Provider identities, periods, timestamps and prices are preserved when supplied. Official roster/game matching remains required.",
		games,
		diagnostics: {
			sourceGames: sourceGames.length,
			returnedGames: games.length,
			matchedPropsInReturnedBooks: matchedProps,
			returnedProps,
			gamesOmitted: Math.max(0, sourceGames.length - 30),
			booksOmitted,
			propsOmitted,
			truncated: sourceGames.length > 30 || booksOmitted > 0 || propsOmitted > 0,
			evidenceGaps: gaps,
			officialIdentityMatchVerified: false
		}
	};
}
function validNbaFeedSample(market, limit) {
	return markets.has(market) && Number.isInteger(limit) && limit >= 1 && limit <= 25;
}
/** Shared native Response handler for the app and the isolated diagnostic-only
* release. load() uses the existing bound provider; no caller-controlled URL. */
async function readNbaFeedDiagnostic(query, load, failureCategory) {
	const market = query.get("market") || "points", rawLimit = query.get("limit"), limit = rawLimit == null ? 2 : Number(rawLimit);
	if (!validNbaFeedSample(market, limit)) return Response.json({ error: "Choose a supported NBA market and an integer limit from 1 to 25." }, {
		status: 400,
		headers: { "Cache-Control": "no-store" }
	});
	try {
		return Response.json({
			...nbaFeedSample(await load(), market, limit),
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		}, { headers: { "Cache-Control": "no-store" } });
	} catch (error) {
		return Response.json({
			error: "NBA quote sample unavailable",
			reason: failureCategory(error)
		}, {
			status: 503,
			headers: { "Cache-Control": "no-store" }
		});
	}
}
// lib/nba-population-diagnostic.ts
const NBA_CENSUS_MARKETS = [
	"points",
	"rebounds",
	"assists",
	"threes_made",
	"pts_rebs_asts",
	"pts_rebs",
	"pts_asts"
];
const hash = (s) => createHash("sha256").update(s).digest("hex");
const bytes = (s) => new TextEncoder().encode(s).byteLength;
const gameFields = [
	"id",
	"gameId",
	"eventId",
	"homeTeam",
	"awayTeam",
	"home_team",
	"away_team",
	"commenceTime",
	"commence_time",
	"startTime",
	"date"
];
const bookFields = [
	"key",
	"id",
	"bookmakerId",
	"name",
	"title",
	"lastUpdate"
];
const identityFields = [
	"id",
	"playerId",
	"playerID",
	"player_id",
	"athleteId",
	"athlete_id",
	"name",
	"displayName",
	"firstName",
	"lastName",
	"teamId",
	"teamName"
];
const propFields = [
	"propId",
	"quoteId",
	"playerId",
	"playerID",
	"player_id",
	"athleteId",
	"athlete_id",
	"gameId",
	"eventId",
	"market",
	"statID",
	"type",
	"periodID",
	"periodId",
	"period",
	"periodName",
	"team",
	"teamName",
	"active",
	"isSuspended",
	"isMain",
	"playerName",
	"player_name",
	"category",
	"line",
	"point",
	"total",
	"overPrice",
	"underPrice",
	"over_price",
	"under_price",
	"lastUpdate",
	"isMainLine",
	"isAlternate",
	"marketStructure",
	"lineType",
	"suspended"
];
const scalar = (v) => v === null || [
	"string",
	"number",
	"boolean"
].includes(typeof v);
function pick(row, keys) {
	const out = {};
	for (const key of keys) if (Object.hasOwn(row || {}, key) && scalar(row[key])) {
		if (typeof row[key] === "string" && bytes(row[key]) > 8192) throw Error("census_field_size");
		out[key] = row[key];
	}
	return out;
}
function propEvidence(p) {
	const out = pick(p, propFields);
	for (const key of ["player", "athlete"]) if (Object.hasOwn(p, key)) {
		if (scalar(p[key])) Object.assign(out, pick(p, [key]));
		else if (p[key] && typeof p[key] === "object" && !Array.isArray(p[key])) out[key] = pick(p[key], identityFields);
	}
	return out;
}
/** Every candidate offer is retained, including invalid/suspended/unpriced
* contracts. Positions are audit coordinates, never invented provider IDs. */
function* offers(payload) {
	let examined = 0, index = 0;
	if (!Array.isArray(payload?.data) || payload.data.length > 64) throw Error("census_schema_or_game_limit");
	for (const [gi, g] of payload.data.entries()) {
		if (!Array.isArray(g?.books) || g.books.length > 64) throw Error("census_book_schema_or_limit");
		for (const [bi, b] of g.books.entries()) {
			if (!Array.isArray(b?.props)) throw Error("census_prop_schema");
			for (const [pi, p] of b.props.entries()) {
				if (++examined > 1e5) throw Error("census_source_prop_limit");
				if (!p || typeof p !== "object") throw Error("census_prop_schema");
				const withoutPeriod = { ...p };
				for (const k of [
					"periodID",
					"periodId",
					"period",
					"periodName"
				]) delete withoutPeriod[k];
				const candidateMarkets = NBA_CENSUS_MARKETS.filter((m) => basketballMarketMatches(withoutPeriod, m));
				if (!candidateMarkets.length) continue;
				if (index >= 25e3) throw Error("census_candidate_limit");
				const prop = propEvidence(p);
				yield {
					type: "offer",
					index: index++,
					sourcePosition: {
						game: gi,
						book: bi,
						prop: pi
					},
					candidateMarkets,
					matchedMarkets: candidateMarkets.filter((m) => basketballMarketMatches(p, m)),
					game: pick(g, gameFields),
					book: pick(b, bookFields),
					prop,
					sourcePropKeys: Object.keys(p),
					omittedPropFields: Object.keys(p).filter((k) => !Object.hasOwn(prop, k)),
					omittedIdentityFields: Object.fromEntries(["player", "athlete"].filter((k) => p[k] && typeof p[k] === "object").map((k) => [k, Object.keys(p[k]).filter((f) => !Object.hasOwn(prop[k] || {}, f))]))
				};
			}
		}
	}
}
/** Two bounded passes: count/hash before headers, then backpressure-driven
* output. No pagination, independent snapshots, durable cache or truncation. */
function nbaPopulationResponse(payload, observedAt, signal) {
	if (!Number.isFinite(Date.parse(observedAt))) throw Error("census_timestamp");
	const digest = createHash("sha256"), counts = Object.fromEntries(NBA_CENSUS_MARKETS.map((m) => [m, 0]));
	let count = 0, totalBytes = 0;
	for (const offer of offers(payload)) {
		if (signal?.aborted) throw signal.reason;
		const line = JSON.stringify(offer) + "\n";
		totalBytes += bytes(line);
		if (totalBytes > 16777216) throw Error("census_response_size");
		digest.update(line);
		count++;
		for (const m of offer.matchedMarkets) counts[m]++;
	}
	const sourceBooks = payload.data.reduce((n, g) => n + g.books.length, 0), sourceProps = payload.data.reduce((n, g) => n + g.books.reduce((b, v) => b + v.props.length, 0), 0);
	const checksum = digest.digest("hex"), snapshot = hash(observedAt + "|" + checksum), iterator = offers(payload), encoder = new TextEncoder();
	let stage = 0, ended = false;
	const stream = new ReadableStream({
		pull(controller) {
			if (signal?.aborted) {
				ended = true;
				iterator.return(void 0);
				controller.error(signal.reason);
				return;
			}
			if (stage === 0) {
				stage = 1;
				controller.enqueue(encoder.encode(JSON.stringify({
					type: "manifest",
					version: 1,
					sport: "nba",
					observedAt,
					snapshot,
					sourceGames: payload.data.length,
					sourceBooks,
					sourceProps,
					outOfScopeOtherCategories: sourceProps - count,
					offerCount: count,
					matchedByMarket: counts,
					offerBytes: totalBytes,
					offersSha256: checksum,
					truncated: false,
					scope: "All seven-market candidate offers from ONE provider payload. observedAt is the diagnostic read time; original quote timestamps are separate. Raw identity/price evidence, not forecasts or verified official identities."
				}) + "\n"));
				return;
			}
			const next = iterator.next();
			if (!next.done) {
				controller.enqueue(encoder.encode(JSON.stringify(next.value) + "\n"));
				return;
			}
			if (!ended) {
				ended = true;
				controller.enqueue(encoder.encode(JSON.stringify({
					type: "complete",
					snapshot,
					offerCount: count,
					offersSha256: checksum
				}) + "\n"));
				controller.close();
			}
		},
		cancel() {
			ended = true;
			iterator.return(void 0);
		}
	});
	return new Response(stream, { headers: {
		"Content-Type": "application/x-ndjson; charset=utf-8",
		"Cache-Control": "no-store",
		"X-Content-Type-Options": "nosniff"
	} });
}
/** Fixed official NBA resources only. No athlete-log retries, alternate host,
* caller-controlled URL, credentials, mutations or validation/restamping. */
function nbaDiagnosticSource(query, now = Date.now()) {
	const kind = query.get("kind"), id = query.get("id") || "", season = query.get("season") || "", date = query.get("date") || "";
	const allowed = /* @__PURE__ */ new Set([
		"sport",
		"mode",
		"kind",
		...kind === "scoreboard" ? ["date"] : kind === "team_schedule" ? ["id", "season"] : ["id"]
	]);
	if ([...query.keys()].some((k) => !allowed.has(k) || query.getAll(k).length !== 1)) throw Error("invalid_source_query");
	const base = "https://site.api.espn.com/apis/site/v2/sports/basketball/nba";
	if (kind === "scoreboard") {
		const stamp = Date.parse(date + "T12:00Z");
		if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Number.isFinite(stamp) || new Date(stamp).toISOString().slice(0, 10) !== date || Math.abs(stamp - now) > 2592e5) throw Error("invalid_source_date");
		return {
			kind,
			url: base + "/scoreboard?limit=200&dates=" + date.replaceAll("-", ""),
			keys: ["events", "leagues"]
		};
	}
	if (!/^\d{1,12}$/.test(id)) throw Error("invalid_source_id");
	if (kind === "summary") return {
		kind,
		url: base + "/summary?event=" + id,
		keys: [
			"header",
			"boxscore",
			"injuries"
		]
	};
	if (kind === "roster") return {
		kind,
		url: base + "/teams/" + id + "/roster",
		keys: ["team", "athletes"]
	};
	const d = new Date(now), current = d.getUTCFullYear() + (d.getUTCMonth() >= 8 ? 1 : 0);
	if (kind === "team_schedule" && season === String(current)) return {
		kind,
		url: base + "/teams/" + id + "/schedule?season=" + season + "&seasontype=2",
		keys: [
			"status",
			"timestamp",
			"season",
			"requestedSeason",
			"team",
			"events"
		]
	};
	throw Error("invalid_source_kind_or_season");
}
function retryTime(value, now, minimum) {
	const n = value == null ? NaN : Number(value), d = value == null ? NaN : Date.parse(value);
	return Math.max(now + minimum, Number.isFinite(n) ? now + n * 1e3 : Number.isFinite(d) ? d : 0);
}
function createNbaOfficialDiagnostic(fetcher = (...args) => globalThis.fetch(...args)) {
	let active = 0;
	const cooldowns = /* @__PURE__ */ new Map();
	return async (request) => {
		let source;
		try {
			source = nbaDiagnosticSource(new URL(request.url).searchParams);
		} catch {
			return Response.json({ error: "Invalid bounded NBA source query" }, { status: 400 });
		}
		const now = Date.now();
		for (const [k, v] of cooldowns) if (v <= now) cooldowns.delete(k);
		const until = Math.max(cooldowns.get(source.url) || 0, cooldowns.get("origin") || 0);
		if (until > now) return Response.json({
			reason: "recorded_source_cooldown",
			source: source.url,
			retryAt: new Date(until).toISOString()
		}, {
			status: 429,
			headers: {
				"Cache-Control": "no-store",
				"Retry-After": String(Math.ceil((until - now) / 1e3))
			}
		});
		if (active >= 2) return Response.json({ reason: "diagnostic_busy" }, {
			status: 429,
			headers: {
				"Retry-After": "1",
				"Cache-Control": "no-store"
			}
		});
		active++;
		let response, reader, canceling;
		const signal = AbortSignal.any([request.signal, AbortSignal.timeout(8e3)]);
		const cancel = () => {
			canceling = reader?.cancel(signal.reason).catch(() => {});
		};
		signal.addEventListener("abort", cancel, { once: true });
		try {
			response = await fetcher(source.url, {
				method: "GET",
				headers: {
					Accept: "application/json",
					"User-Agent": PUBLIC_PROVIDER_USER_AGENT
				},
				cache: "no-store",
				redirect: "manual",
				signal
			});
			if (!response.ok) {
				const status = response.status;
				if ([403, 429].includes(status)) {
					if (cooldowns.size >= 64) cooldowns.delete(cooldowns.keys().next().value);
					cooldowns.set(status === 429 ? "origin" : source.url, retryTime(response.headers.get("Retry-After"), Date.now(), status === 429 ? 6e4 : 36e5));
				}
				await response.body?.cancel();
				return Response.json({
					source: source.url,
					sourceStatus: status,
					observedAt: (/* @__PURE__ */ new Date()).toISOString(),
					durationMs: Date.now() - now,
					responseDate: response.headers.get("Date"),
					responseAge: response.headers.get("Age"),
					upstreamRay: response.headers.get("CF-Ray"),
					retryAfter: response.headers.get("Retry-After"),
					reason: status === 403 ? "official_source_access_denied" : status === 429 ? "official_source_rate_limited" : status >= 300 && status < 400 ? "official_source_redirect_rejected" : "official_source_http_error"
				}, {
					status: 503,
					headers: { "Cache-Control": "no-store" }
				});
			}
			reader = response.body?.getReader();
			if (!reader) throw Error("source_body_missing");
			const parts = [];
			let size = 0;
			for (;;) {
				if (signal.aborted) throw signal.reason;
				const part = await reader.read();
				if (signal.aborted) throw signal.reason;
				if (part.done) break;
				size += part.value.byteLength;
				if (size > 2097152) throw Error("source_body_limit");
				parts.push(part.value);
			}
			const body = new Uint8Array(size);
			let offset = 0;
			for (const p of parts) {
				body.set(p, offset);
				offset += p.length;
			}
			const parsed = JSON.parse(new TextDecoder().decode(body));
			if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw Error("source_schema");
			const payload = Object.fromEntries(source.keys.filter((k) => Object.hasOwn(parsed, k)).map((k) => [k, k === "boxscore" ? { players: parsed.boxscore?.players } : parsed[k]]));
			return Response.json({
				version: 1,
				source: source.url,
				kind: source.kind,
				sourceStatus: response.status,
				requestStartedAt: new Date(now).toISOString(),
				observedAt: (/* @__PURE__ */ new Date()).toISOString(),
				durationMs: Date.now() - now,
				responseDate: response.headers.get("Date"),
				responseAge: response.headers.get("Age"),
				lastModified: response.headers.get("Last-Modified"),
				etag: response.headers.get("ETag"),
				upstreamRay: response.headers.get("CF-Ray"),
				rawBodySha256: createHash("sha256").update(body).digest("hex"),
				payloadSha256: hash(JSON.stringify(payload)),
				payload,
				scope: "Actual unvalidated official source receipt. Validate unchanged model completeness/freshness rules offline; no production evidence written."
			}, { headers: { "Cache-Control": "no-store" } });
		} catch (error) {
			await reader?.cancel().catch(() => {});
			if (!reader) await response?.body?.cancel().catch(() => {});
			return Response.json({
				source: source.url,
				reason: signal.aborted ? "official_source_canceled_or_timeout" : "official_source_body_invalid",
				observedAt: (/* @__PURE__ */ new Date()).toISOString()
			}, {
				status: 503,
				headers: { "Cache-Control": "no-store" }
			});
		} finally {
			signal.removeEventListener("abort", cancel);
			await canceling;
			reader?.releaseLock();
			active--;
		}
	};
}
// scripts/nba-odds-diagnostic-entry.mjs
/** Diagnostic-only overlay; all other requests remain on the approved fallback. */
const official = createNbaOfficialDiagnostic();
function isNbaOddsDiagnostic(request) {
	const u = new URL(request.url);
	return request.method === "GET" && u.pathname === "/api/market-coverage" && u.searchParams.get("sport") === "nba" && [
		"feed-sample",
		"feed-census",
		"source-census"
	].includes(u.searchParams.get("mode"));
}
async function handleNbaOddsDiagnostic(request) {
	const q = new URL(request.url).searchParams;
	if (q.get("mode") === "source-census") return official(request);
	if (q.get("mode") !== "feed-census") return readNbaFeedDiagnostic(q, () => getOwlsPayload("nba"), owlsFailureCategory);
	if ([...q.keys()].some((k) => !["sport", "mode"].includes(k) || q.getAll(k).length !== 1)) return Response.json({ error: "The census exports all seven markets; no filters or pagination." }, { status: 400 });
	try {
		if (request.signal.aborted) throw request.signal.reason;
		return nbaPopulationResponse(await getOwlsPayload("nba"), (/* @__PURE__ */ new Date()).toISOString(), request.signal);
	} catch (error) {
		const reason = /^census_[a-z_]+$/.test(String(error?.message)) ? error.message : owlsFailureCategory(error);
		return Response.json({
			error: "Complete NBA census unavailable",
			reason
		}, {
			status: 503,
			headers: { "Cache-Control": "no-store" }
		});
	}
}
export { handleNbaOddsDiagnostic, isNbaOddsDiagnostic };
